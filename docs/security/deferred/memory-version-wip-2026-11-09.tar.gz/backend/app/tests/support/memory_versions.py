"""显式构造受信内部记忆意图/版本；历史负例直接加原始行，不使用此助手。"""

from app.memory.versions import register_candidate_version,register_memory_intent
from app.storage.memory_candidates import MemoryCandidateRepository


def register_intent(db,run_id,tenant_id="tenant_1",user_id="user_1",request_id=None):
    return register_memory_intent(db,run_id=run_id,tenant_id=tenant_id,user_id=user_id,request_id=request_id or run_id)


def seed_candidate(db,record):
    register_intent(db,record.run_id,record.tenant_id,record.user_id)
    db.add(record)
    db.flush([record])
    register_candidate_version(db,record)
    return record


def seed_candidates(db,records):
    for record in records:
        seed_candidate(db,record)


def save_candidate(db,candidate,*,tenant_id,user_id,run_id):
    register_intent(db,run_id,tenant_id,user_id)
    return MemoryCandidateRepository(db).save_candidate(candidate,tenant_id=tenant_id,user_id=user_id,run_id=run_id)
