from app.graph.runtime import run_question_answer_graph
from app.memory.versions import memory_read_context
from app.memory.synchronizer import MemoryStoreSynchronizer
from app.tests.support.memory_versions import seed_candidate
from app.tests.unit.test_memory_synchronizer import _candidate
from app.tests.integration.test_live_postgres_memory_synchronizer import _business_session_factory
from app.tests.support.workflow_llm import WorkflowTestLlm
from app.tests.support.postgres_store import LivePostgresStore
from app.tools.registry import ToolRegistry


pytest_plugins = ("app.tests.support.postgres_store",)


def _put_preference(factory,store,tenant_id,user_id,key,content):
    run_id=f"{tenant_id}-{user_id}"
    with factory() as db:
        seed_candidate(db,_candidate(candidate_id=f"{run_id}-{key}",run_id=run_id,tenant_id=tenant_id,user_id=user_id,memory_key=key,content=content))
        db.commit()
    MemoryStoreSynchronizer(session_factory=factory,store=store).sync_run(run_id)


def test_graph_reads_runtime_preferences_and_isolates_identities(
    business_intent_catalog,
    live_postgres_store: LivePostgresStore,
):
    store = live_postgres_store.store
    with _business_session_factory() as factory:
        _put_preference(factory,store, "tenant-a", "user-a", "language", "使用英文回答")
        _put_preference(factory,store, "tenant-a", "user-a", "response_detail", "回答简洁")
        _put_preference(factory,store, "tenant-b", "user-a", "language", "使用日文回答")
        _put_preference(factory,store, "tenant-a", "user-b", "language", "使用法文回答")
    
        with memory_read_context(factory,tenant_id="tenant-a",user_id="user-a"):
            state = run_question_answer_graph(
                business_intent_catalog=business_intent_catalog,
                session_id="memory-runtime",
                tenant_id="tenant-a",
                user_id="user-a",
                user_message="你好",
                store=store,
                llm_client=WorkflowTestLlm(),
                tool_registry_factory=ToolRegistry,
            )

    assert state["plan"]["response_policy"]["language"] == "english"
    assert state["draft_answer"]["response_policy"]["language"] == "english"
    assert state["draft_answer"]["response_policy"]["detail"] == "concise"
    assert "日文" not in state["draft_answer"]["content"]
    assert "法文" not in state["draft_answer"]["content"]
