"""真实候选/仓储/同步的顺序测试，Store只在进程内保存合成数据。"""

from copy import deepcopy
from datetime import UTC,datetime

import pytest
from langgraph.runtime import Runtime
from langgraph.store.base import Item
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from app.memory.candidates import propose_explicit_preference_candidates
from app.memory.preferences import recall_user_preferences,experience_namespace
from app.memory.synchronizer import MemoryStoreSynchronizer
from app.storage.memory_candidates import MemoryCandidateRepository
from app.storage.models import Base
from app.tests.support.no_httpx_network import block_default_httpx_network  # noqa: F401
from app.tests.unit.test_memory_preferences import _state


@pytest.fixture
def database(tmp_path):
    engine=create_engine(f"sqlite:///{tmp_path/'versions.db'}",connect_args={"timeout":10})
    Base.metadata.create_all(engine)
    yield sessionmaker(bind=engine,expire_on_commit=False)
    engine.dispose()


class Store:
    def __init__(self):
        self.values={}
        self.writes=[]

    def put(self,namespace,key,value):
        self.values[(namespace,key)]=deepcopy(value)
        self.writes.append((namespace,key,deepcopy(value)))

    def get(self,namespace,key):
        value=self.values.get((namespace,key))
        if value is None:
            return None
        now=datetime.now(UTC)
        return Item(value=deepcopy(value),key=key,namespace=namespace,created_at=now,updated_at=now)

    def search(self,namespace,**kwargs):
        return [self.get(ns,key) for ns,key in self.values if ns==namespace]


def candidate(request_id,text="以后回答使用中文"):
    return propose_explicit_preference_candidates(user_message="请记住："+text,
        tenant_id="tenant-1",user_id="user-1",request_id=request_id)[0]


def save(factory,request_id,text="以后回答使用中文",status=None):
    from app.memory.versions import register_memory_intent
    value=candidate(request_id,text)
    if status:
        value=value.model_copy(update={"approval_status":status})
    with factory() as db:
        register_memory_intent(db,run_id=request_id,tenant_id="tenant-1",user_id="user-1",request_id=request_id)
        row=MemoryCandidateRepository(db).save_candidate(value,tenant_id="tenant-1",user_id="user-1",run_id=request_id)
        db.commit()
    return row


def read(factory,store,*,tenant="tenant-1",user="user-1"):
    try:
        from app.memory.versions import memory_read_context
    except ImportError:
        pytest.fail("缺少可信版本读取上下文。")
    with memory_read_context(factory,tenant_id=tenant,user_id=user):
        return recall_user_preferences(Runtime(store=store),_state())


def test_new_intent_has_new_identity_and_same_intent_retry_is_stable():
    assert candidate("r1").candidate_id==candidate("r1").candidate_id
    assert candidate("r1").candidate_id!=candidate("r2").candidate_id


def test_new_approved_intent_does_not_inherit_previous_rejection(database):
    old=save(database,"r1","我的联系邮箱是 synthetic@example.invalid",status="rejected")
    new=save(database,"r2","我的联系邮箱是 synthetic@example.invalid",status="approved")
    assert old.candidate_id!=new.candidate_id
    assert new.approval_status=="approved"


def test_old_retry_cannot_replace_new_accepted_preference(database):
    old=save(database,"old")
    newer=save(database,"new","以后回答使用英文")
    store=Store()
    sync=MemoryStoreSynchronizer(session_factory=database,store=store)
    assert sync.sync_run("new")==1
    sync.sync_run("old")
    assert [(p.memory_key,p.content) for p in read(database,store)]==[("language",newer.content)]
    assert all(value[2]["content"]!=old.content for value in store.writes)


def test_late_old_approval_does_not_reorder_intent(database):
    text1="关注邮箱 Old@example.invalid"
    text2="关注邮箱 New@example.invalid"
    save(database,"old",text1,status="pending")
    newer=save(database,"new",text2,status="approved")
    save(database,"old",text1,status="approved")
    store=Store()
    sync=MemoryStoreSynchronizer(session_factory=database,store=store)
    assert sync.sync_run("new")==1
    sync.sync_run("old")
    assert [p.content for p in read(database,store)]==[newer.content]


def test_missing_trusted_context_does_not_use_unverified_store_value():
    store=Store()
    store.put(experience_namespace("tenant-1","user-1"),"language",{
        "memory_type":"user_preference","memory_key":"language","content":"使用英文"})
    assert recall_user_preferences(Runtime(store=store),_state())==[]


@pytest.mark.parametrize("field",["eligible","pointer","intent_owner","intent_missing"])
def test_invalid_latest_version_does_not_fall_back_to_old_value(database,field):
    from app.storage.models import MemoryCandidateRecord,MemoryCandidateVersion,MemoryIntentRecord
    old=save(database,"old")
    store=Store()
    sync=MemoryStoreSynchronizer(session_factory=database,store=store)
    sync.sync_run("old")
    new=save(database,"new","以后回答使用英文")
    sync.sync_run("new")
    with database() as db:
        row=db.get(MemoryCandidateRecord,new.candidate_id)
        if field=="eligible":
            db.get(MemoryCandidateVersion,row.memory_version_id).is_eligible=False
        elif field=="pointer":
            row.memory_version_id=None
        else:
            intent=db.scalar(__import__("sqlalchemy").select(MemoryIntentRecord).where(MemoryIntentRecord.run_id=="new"))
            if field=="intent_owner":
                intent.user_id="other"
            else:
                db.delete(intent)
        db.commit()
    assert read(database,store)==[]


def test_late_old_store_completion_only_writes_old_key(database):
    save(database,"old")
    store=Store()
    sync=MemoryStoreSynchronizer(session_factory=database,store=store)
    sync.sync_run("old")
    old_write=store.writes[-1]
    new=save(database,"new","以后回答使用英文")
    sync.sync_run("new")
    store.put(*old_write)  # 模拟旧连接/锁失效后，远端旧put才最终完成。
    assert [p.content for p in read(database,store)]==[new.content]
    assert old_write[1]!=store.writes[-2][1]


def test_intent_order_is_allocated_before_slow_planning(database):
    from app.memory.versions import register_memory_intent
    with database() as db:
        for request in ("old","new"):
            register_memory_intent(db,run_id=request,tenant_id="tenant-1",user_id="user-1",request_id=request)
        db.commit()
    new=save(database,"new","以后回答使用英文")
    save(database,"old")  # 旧任务模型较慢，候选在新任务以后才落库。
    store=Store()
    sync=MemoryStoreSynchronizer(session_factory=database,store=store)
    sync.sync_run("new")
    sync.sync_run("old")
    assert [p.content for p in read(database,store)]==[new.content]


def test_effective_nonterminal_change_schedules_new_version_sync(database):
    original=save(database,"r1")
    store=Store()
    sync=MemoryStoreSynchronizer(session_factory=database,store=store)
    sync.sync_run("r1")
    old_version=original.memory_version_id
    with database() as db:
        row=MemoryCandidateRepository(db).save_candidate(candidate("r1").model_copy(update={"confidence":0.95}),
            tenant_id="tenant-1",user_id="user-1",run_id="r1")
        db.commit()
        assert row.memory_version_id!=old_version
        assert row.store_sync_status=="pending"
    assert sync.sync_run("r1")==1
    assert read(database,store)[0].content==original.content
