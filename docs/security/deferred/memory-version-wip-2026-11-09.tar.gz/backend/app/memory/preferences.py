import logging
from collections.abc import Callable, Mapping
from dataclasses import dataclass

from langgraph.runtime import Runtime
from langgraph.store.base import Item

from app.core.config import settings
from app.memory.versions import latest_snapshots,read_context
from app.graph.state import AgentState
from app.security.context_content import context_content_is_safe

logger = logging.getLogger(__name__)
_PREFERENCE_MEMORY_TYPE = "user_preference"


@dataclass(frozen=True)
class UserPreference:
    memory_key: str
    content: str


def experience_namespace(tenant_id: str, user_id: str) -> tuple[str, ...]:
    return ("tenants", tenant_id, "users", user_id, "experiences")


def decode_user_preference(item: Item) -> UserPreference | None:
    value = item.value
    if not isinstance(value, Mapping):
        return None
    if value.get("memory_type") != _PREFERENCE_MEMORY_TYPE:
        return None
    content = value.get("content")
    memory_key = value.get("memory_key", item.key)
    if not isinstance(content, str) or not content.strip():
        return None
    if not isinstance(memory_key, str) or not memory_key.strip():
        return None
    if not context_content_is_safe({"memory_key": memory_key, "content": content}):
        return None
    return UserPreference(memory_key=memory_key, content=content.strip())


def recall_user_preferences(
    runtime: Runtime | None,
    state: AgentState,
    *,
    on_failure: Callable[[AgentState], None] | None = None,
) -> list[UserPreference]:
    store = runtime.store if runtime is not None else None
    if store is None:
        _record_recall_failure(state, on_failure=on_failure, reason="store_unavailable")
        return []
    try:
        context=read_context()
        if (state["tenant_id"],state["user_id"])!=(context.tenant_id,context.user_id):
            raise ValueError("记忆主体不一致。")
        with context.session_factory() as db:
            snapshots=latest_snapshots(db,tenant_id=context.tenant_id,user_id=context.user_id,
                limit=settings.experience_memory_recall_limit)
        namespace=experience_namespace(context.tenant_id,context.user_id)
        accepted={}
        for snapshot in snapshots:
            item=store.get(namespace,snapshot.store_key)
            if (item is not None and item.namespace==namespace and item.key==snapshot.store_key
                and isinstance(item.value,Mapping) and dict(item.value)==snapshot.store_value):
                preference=decode_user_preference(item)
                if preference is not None:
                    accepted[snapshot]=preference
        # 外部Store等待期间可能出现新意图，使用独立SQL快照再次确认，不能返回旧头。
        with context.session_factory() as db:
            current=set(latest_snapshots(db,tenant_id=context.tenant_id,user_id=context.user_id,
                limit=settings.experience_memory_recall_limit))
        preferences=[preference for snapshot,preference in accepted.items() if snapshot in current]
        return preferences
    except Exception:  # noqa: BLE001 - 召回故障降级为空，不记录原始异常。
        _record_recall_failure(state, on_failure=on_failure, reason="store_read_failed")
        return []


def planning_preference_constraints(
    preferences: list[UserPreference],
) -> dict[str, str]:
    constraints: dict[str, str] = {}
    for preference in preferences:
        content = preference.content.lower()
        if preference.memory_key == "language":
            if "英文" in content or "english" in content:
                constraints["language"] = "english"
            elif "中文" in content or "chinese" in content:
                constraints["language"] = "chinese"
        elif preference.memory_key == "response_detail":
            if any(term in content for term in ("简洁", "简短", "精简", "concise")):
                constraints["detail"] = "concise"
            elif any(term in content for term in ("详细", "展开", "detail")):
                constraints["detail"] = "detailed"
        elif preference.memory_key == "focus_domain":
            constraints["focus_domain"] = preference.content
    return constraints


def presentation_preference_constraints(
    preferences: list[UserPreference],
) -> dict[str, str]:
    constraints = planning_preference_constraints(preferences)
    return {
        key: value
        for key, value in constraints.items()
        if key in {"language", "detail"}
    }


def _record_recall_failure(
    state: AgentState,
    *,
    on_failure: Callable[[AgentState], None] | None,
    reason: str,
) -> None:
    logger.warning(
        "experience memory recall failed",
        extra={
            "event": "experience_memory_recall_failed",
            "reason": reason,
            "tenant_id": state["tenant_id"],
            "user_id": state["user_id"],
            "trace_id": state["trace_id"],
        },
    )
    if on_failure is not None:
        on_failure(state)
