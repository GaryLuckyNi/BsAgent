"""数据库权威记忆版本与受信读取上下文；Store内容不能自行授予资格。"""

import hashlib
import json
from contextlib import contextmanager
from contextvars import ContextVar
from dataclasses import dataclass

from sqlalchemy import func,select,or_,and_

from app.security.context_content import context_content_is_safe
from app.security.memory_candidate import MemoryCandidateConflict,candidate_body,memory_approval_required
from app.storage.models import MemoryCandidateRecord,MemoryCandidateVersion,MemoryIntentRecord


class MemoryVersionUnavailable(RuntimeError):
    code="memory_version_unavailable"
    http_status=503
    node_name="memory"
    message="记忆版本暂不可用，请稍后重试或重新提出偏好。"

    def __init__(self):
        super().__init__(self.message)


def _digest(value):
    return hashlib.sha256(json.dumps(value,ensure_ascii=False,sort_keys=True,separators=(",",":"),allow_nan=False).encode()).hexdigest()


def body_digest(candidate):
    return _digest(candidate_body(candidate))


def register_memory_intent(db,*,run_id,tenant_id,user_id,request_id):
    """仅由已验证任务初始化/显式内部宿主注册，同请求重试不重新排号。"""
    row=db.scalar(select(MemoryIntentRecord).where(MemoryIntentRecord.run_id==run_id))
    if row is not None:
        if (row.tenant_id,row.user_id,row.request_id)!=(tenant_id,user_id,request_id):
            raise MemoryCandidateConflict()
        return row
    row=MemoryIntentRecord(run_id=run_id,tenant_id=tenant_id,user_id=user_id,request_id=request_id)
    db.add(row)
    db.flush([row])
    return row


def register_candidate_version(db,candidate):
    intent=db.scalar(select(MemoryIntentRecord).where(MemoryIntentRecord.run_id==candidate.run_id))
    if intent is None or (intent.tenant_id,intent.user_id)!=(candidate.tenant_id,candidate.user_id):
        raise MemoryVersionUnavailable()
    digest=body_digest(candidate)
    eligible=(candidate.approval_status in {"approved","not_required"}
              and candidate.sensitivity in {"low","medium","high"}
              and not memory_approval_required(candidate)
              and context_content_is_safe(candidate_body(candidate)))
    current=db.get(MemoryCandidateVersion,candidate.memory_version_id) if candidate.memory_version_id is not None else None
    if current is not None and (
        current.candidate_id,current.intent_order,current.tenant_id,current.user_id,current.memory_type,current.memory_key,current.body_digest
    )==(candidate.candidate_id,intent.order_id,candidate.tenant_id,candidate.user_id,candidate.memory_type,candidate.memory_key,digest):
        current.is_eligible=eligible
        return current
    version=MemoryCandidateVersion(candidate_id=candidate.candidate_id,intent_order=intent.order_id,
        tenant_id=candidate.tenant_id,user_id=candidate.user_id,memory_type=candidate.memory_type,
        memory_key=candidate.memory_key,body_digest=digest,is_eligible=eligible)
    db.add(version)
    db.flush([version])
    candidate.memory_version_id=version.version_id
    db.flush([candidate])
    return version


@dataclass(frozen=True)
class MemorySnapshot:
    version_id:int
    intent_order:int
    candidate_id:str
    body_digest:str
    tenant_id:str
    user_id:str
    memory_type:str
    memory_key:str
    content:str
    confidence:float
    sensitivity:str
    source:str|None

    @property
    def store_key(self):
        return "prefv1_"+_digest([self.tenant_id,self.user_id,self.memory_key,self.intent_order,self.version_id,self.candidate_id,self.body_digest])

    @property
    def store_value(self):
        return {"memory_type":self.memory_type,"memory_key":self.memory_key,"content":self.content,
                "confidence":self.confidence,"source":self.source,
                "_memory_version":{"format":1,"version_id":self.version_id,"intent_order":self.intent_order,
                    "candidate_id":self.candidate_id,"body_digest":self.body_digest}}


def capture_version(db,candidate):
    if candidate.memory_version_id is None:
        raise MemoryVersionUnavailable()
    version=db.get(MemoryCandidateVersion,candidate.memory_version_id,populate_existing=True)
    intent=db.scalar(select(MemoryIntentRecord).where(MemoryIntentRecord.run_id==candidate.run_id))
    if version is None or intent is None or not version.is_eligible or (
        version.candidate_id,version.intent_order,version.tenant_id,version.user_id,version.memory_type,version.memory_key,version.body_digest
    )!=(candidate.candidate_id,intent.order_id,candidate.tenant_id,candidate.user_id,candidate.memory_type,candidate.memory_key,body_digest(candidate)) or (
        intent.tenant_id,intent.user_id)!=(candidate.tenant_id,candidate.user_id) or (
        candidate.approval_status not in {"approved","not_required"} or memory_approval_required(candidate)
        or not context_content_is_safe(candidate_body(candidate))):
        raise MemoryVersionUnavailable()
    return MemorySnapshot(version.version_id,intent.order_id,candidate.candidate_id,version.body_digest,
        candidate.tenant_id,candidate.user_id,candidate.memory_type,candidate.memory_key,candidate.content,
        candidate.confidence,candidate.sensitivity,candidate.source)


def _ranked(tenant_id,user_id,memory_key=None):
    intent,candidate,version=MemoryIntentRecord,MemoryCandidateRecord,MemoryCandidateVersion
    rank=func.row_number().over(partition_by=(candidate.memory_type,candidate.memory_key),
        order_by=(func.coalesce(intent.order_id,version.intent_order,2**63-1).desc(),func.coalesce(candidate.memory_version_id,2**63-1).desc(),candidate.candidate_id.desc())).label("position")
    # 先选最新应受核验的意图，再验证版本元数据；损坏/丢失不能使查询退回旧值。
    query=select(candidate.candidate_id,rank).outerjoin(intent,intent.run_id==candidate.run_id).outerjoin(
        version,version.version_id==candidate.memory_version_id).where(
        candidate.tenant_id==tenant_id,candidate.user_id==user_id,
        or_(intent.order_id.is_not(None),candidate.memory_version_id.is_not(None)),
        candidate.memory_type=="user_preference",or_(candidate.approval_status=="approved",
            and_(candidate.approval_status=="not_required",candidate.sensitivity=="low")))
    if memory_key is not None:
        query=query.where(candidate.memory_key==memory_key)
    return query.subquery()


def latest_snapshots(db,*,tenant_id,user_id,limit=8,memory_key=None):
    if type(limit) is not int or not 1<=limit<=64:
        raise MemoryVersionUnavailable()
    ranked=_ranked(tenant_id,user_id,memory_key)
    records=db.scalars(select(MemoryCandidateRecord).join(ranked,
        ranked.c.candidate_id==MemoryCandidateRecord.candidate_id).where(ranked.c.position==1)
        .order_by(MemoryCandidateRecord.memory_key).limit(limit).execution_options(populate_existing=True))
    return [capture_version(db,record) for record in records]


def is_current_version(db,snapshot):
    latest=latest_snapshots(db,tenant_id=snapshot.tenant_id,user_id=snapshot.user_id,memory_key=snapshot.memory_key,limit=1)
    return latest==[snapshot]


@dataclass(frozen=True)
class _ReadContext:
    session_factory:object
    tenant_id:str
    user_id:str


_read_context=ContextVar("memory_read_context",default=None)


@contextmanager
def memory_read_context(factory,*,tenant_id,user_id):
    token=_read_context.set(_ReadContext(factory,tenant_id,user_id))
    try:
        yield
    finally:
        _read_context.reset(token)


def read_context():
    from app.security.run_budget import current_budget
    binding=current_budget()
    if binding is not None:
        return _ReadContext(binding.session_factory,binding.tenant_id,binding.user_id)
    context=_read_context.get()
    if context is None:
        raise MemoryVersionUnavailable()
    return context
