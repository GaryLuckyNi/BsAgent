"""记忆意图顺序及可核对版本；不自动为历史候选补发资格。"""

import sqlalchemy as sa
from alembic import op

revision="20261108_0020"
down_revision="20261108_0019"
branch_labels=None
depends_on=None


def upgrade():
    with op.batch_alter_table("memory_candidates") as batch:
        batch.add_column(sa.Column("memory_version_id",sa.BigInteger(),nullable=True))
        batch.create_check_constraint("ck_memory_candidate_version","memory_version_id IS NULL OR memory_version_id > 0")
    op.create_table("memory_intents",
        sa.Column("order_id",sa.BigInteger().with_variant(sa.Integer(),"sqlite"),primary_key=True,autoincrement=True),
        sa.Column("run_id",sa.String(64),nullable=False,unique=True),
        *(sa.Column(key,sa.String(64),nullable=False) for key in ("tenant_id","user_id","request_id")),
        sqlite_autoincrement=True)
    op.create_table("memory_candidate_versions",
        sa.Column("version_id",sa.BigInteger().with_variant(sa.Integer(),"sqlite"),primary_key=True,autoincrement=True),
        sa.Column("candidate_id",sa.String(128),sa.ForeignKey("memory_candidates.candidate_id",ondelete="CASCADE"),nullable=False),
        sa.Column("intent_order",sa.BigInteger(),sa.ForeignKey("memory_intents.order_id"),nullable=False),
        *(sa.Column(key,sa.String(64),nullable=False) for key in ("tenant_id","user_id","memory_type")),
        sa.Column("memory_key",sa.String(128),nullable=False),
        sa.Column("body_digest",sa.String(64),nullable=False),
        sa.Column("is_eligible",sa.Boolean(),nullable=False),sqlite_autoincrement=True)
    op.create_index("ix_memory_versions_owner_key","memory_candidate_versions",
        ["tenant_id","user_id","memory_type","memory_key","is_eligible","intent_order","version_id"])


def downgrade():
    op.drop_index("ix_memory_versions_owner_key",table_name="memory_candidate_versions")
    op.drop_table("memory_candidate_versions")
    op.drop_table("memory_intents")
    with op.batch_alter_table("memory_candidates") as batch:
        batch.drop_constraint("ck_memory_candidate_version",type_="check")
        batch.drop_column("memory_version_id")
